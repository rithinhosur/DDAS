from django.apps import AppConfig


class DdpConfig(AppConfig):
    name = 'ddp'
